<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
validateSession();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = $_POST['rating'] ?? 0;
    $comment = $_POST['comment'] ?? '';
    $user_id = $_SESSION['user']['id'];
    
    // Validasi rating
    if ($rating < 1 || $rating > 5) {
        header("Location: reviews.php?error=Rating+tidak+valid");
        exit();
    }
    
    // Simpan ulasan ke database
    $stmt = $conn->prepare("INSERT INTO reviews (user_id, rating, comment) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $user_id, $rating, $comment);
    
    if ($stmt->execute()) {
        header("Location: reviews.php?success=Ulasan+berhasil+disimpan");
    } else {
        header("Location: reviews.php?error=Gagal+menyimpan+ulasan");
    }
    exit();
}

// Ambil ulasan user
$user_reviews = [];
$stmt = $conn->prepare("SELECT * FROM reviews WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $_SESSION['user']['id']);
$stmt->execute();
$user_reviews = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Ambil data statistik ulasan
$review_stats = [
    'average' => 0,
    'count' => 0
];
$result = $conn->query("SELECT AVG(rating) as average, COUNT(*) as count FROM reviews");
if ($result && $row = $result->fetch_assoc()) {
    $review_stats = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ulasan - Playlandia</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    @font-face {
      font-family: 'Nexa';
      src: url('soopafre.ttf');
    }
    
    body {
      background-image: url('background.png');
      font-family: Arial, sans-serif;
      color: rgb(82, 44, 1);
      background-color: #5F8B4C;
      background-size: cover;
      background-attachment: fixed;
      min-height: 100vh;
    }

    .navbar {
      background-color: #5F8B4C;
      border-bottom: 5px solid rgb(255, 191, 0);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .navbar img {
      width: 50px;
      height: auto;
      transition: transform 0.3s ease;
    }

    .navbar img:hover {
      transform: scale(1.1);
    }

    h1, h2, h3, h4, h5, h6 {
      font-family: 'Nexa', sans-serif;
      color: #FFFBDE;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }

    .welcome-section {
      background: linear-gradient(135deg, rgba(95, 139, 76, 0.9) 0%, rgba(255, 215, 0, 0.8) 100%);
      padding: 2rem 0;
      margin-bottom: 2rem;
      border-radius: 0 0 20px 20px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
    }

    .custom-btn {
      background-color: rgb(226, 49, 49);
      border-color: rgb(255, 191, 0);
      color: white;
      font-family: 'Nexa', sans-serif;
      font-size: 1rem;
      padding: 0.5rem 1.5rem;
      border-radius: 50px;
      transition: all 0.3s ease;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .custom-btn:hover {
      background-color: #FFD700;
      border-color: #5F8B4C;
      color: #5F8B4C;
      box-shadow: 0 6px 12px rgba(95, 139, 76, 0.3);
      transform: translateY(-2px);
    }

    .btn-play {
      background-color: #FFD700;
      color: #5F8B4C;
      font-family: 'Nexa', sans-serif;
      padding: 0.5rem 1.5rem;
      border-radius: 50px;
      text-decoration: none;
      display: inline-block;
      transition: all 0.3s ease;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      border: none;
    }

    .btn-play:hover {
      background-color: #5F8B4C;
      color: #FFFBDE;
      transform: translateY(-2px);
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    }

    .card {
      background: #FFFBDE;
      border-radius: 15px;
      border: none;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
      margin-bottom: 20px;
    }

    .section-title {
      font-family: 'Nexa', sans-serif;
      color: #FFFBDE;
      text-align: center;
      margin: 2rem 0;
      font-size: 2rem;
      position: relative;
    }

    .section-title:after {
      content: "";
      display: block;
      width: 100px;
      height: 4px;
      background: linear-gradient(to right, #5F8B4C, #FFD700);
      margin: 0.5rem auto 0;
      border-radius: 2px;
    }

    .rating-stars {
      color: #FFD700;
      font-size: 1.5rem;
    }

    .review-card {
      border-left: 4px solid #5F8B4C;
      padding: 15px;
      margin-bottom: 15px;
      background-color: #FFFBDE;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .review-header {
      display: flex;
      justify-content: space-between;
      margin-bottom: 10px;
    }

    .review-user {
      font-weight: bold;
      color: #5F8B4C;
      font-family: 'Nexa', sans-serif;
    }

    .review-date {
      color: #6c757d;
      font-size: 0.9rem;
    }

    .form-control:focus {
      border-color: #5F8B4C;
      box-shadow: 0 0 0 0.25rem rgba(95, 139, 76, 0.25);
    }

    .balance {
      font-family: 'Nexa', sans-serif;
      font-size: 1.2rem;
      color: #FFFBDE;
      background-color: rgba(95, 139, 76, 0.7);
      padding: 0.5rem 1rem;
      border-radius: 50px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .alert {
      border-radius: 10px;
    }

    select.form-control {
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #ced4da;
    }

    .rating-option {
      display: inline-block;
      margin-right: 10px;
    }

    .rating-option input[type="radio"] {
      display: none;
    }

    .rating-option label {
      cursor: pointer;
      font-size: 1.5rem;
      color: #ddd;
    }

    .rating-option input[type="radio"]:checked ~ label {
      color: #FFD700;
    }

    .rating-option input[type="radio"]:hover ~ label {
      color: #FFD700;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg sticky-top">
    <div class="container-fluid">
      <div class="d-flex align-items-center">
        <img src="logo.png" alt="Logo Playlandia">
        <h1 class="ms-2">PLAYLANDIA</h1>
      </div>
      
      <div class="ms-auto d-flex align-items-center gap-3">
        <span class="balance">Balance: Rp <?= number_format($_SESSION['user']['saldo'], 0, ',', '.') ?></span>
        <button class="btn custom-btn" data-bs-toggle="modal" data-bs-target="#topupModal">
          <i class="fas fa-coins"></i> Top Up
        </button>
        <button class="btn custom-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu" aria-controls="offcanvasMenu">
          <i class="fas fa-bars"></i>
        </button>
      </div>
    </div>
  </nav>

  <!-- Offcanvas Menu -->
  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasMenu" aria-labelledby="offcanvasMenuLabel">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="offcanvasMenuLabel">Profile User</h5>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <div class="user-profile">
        <h5><?= htmlspecialchars($_SESSION['user']['username']) ?></h5>
        <p><i class="fas fa-wallet me-2"></i> Balance: Rp <?= number_format($_SESSION['user']['saldo'], 0, ',', '.') ?></p>
        <?php if (isset($_SESSION['user']['email'])): ?>
          <p><i class="fas fa-envelope me-2"></i> <?= htmlspecialchars($_SESSION['user']['email']) ?></p>
        <?php endif; ?>
      </div>
      
      <ul class="offcanvas-nav">
        <li>
          <a href="home.php">
            <i class="fas fa-home"></i> Home
          </a>
        </li>
        <li>
          <a href="#" data-bs-toggle="modal" data-bs-target="#transactionModal">
            <i class="fas fa-history"></i> Transaction History
          </a>
        </li>
        <li>
          <a href="reviews.php">
            <i class="fas fa-star"></i> Ulasan Saya
          </a>
        </li>
        <li>
          <a href="logout.php">
            <i class="fas fa-sign-out-alt"></i> Logout
          </a>
        </li>
      </ul>
    </div>
    <div class="offcanvas-footer text-center">
      <small>&copy; 2025 Playlandia. All rights reserved.</small>
    </div>
  </div>

  <!-- Welcome Section -->
  <section class="welcome-section">
    <div class="container text-center">
      <h1 class="welcome-title">ULASAN ANDA</h1>
      <p class="welcome-subtitle" style="color: #FFFBDE;">Bagikan pengalaman Anda bermain di Playlandia</p>
    </div>
  </section>

  <?php if (isset($_GET['error'])): ?>
    <div class="container">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_GET['error']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    </div>
  <?php endif; ?>

  <?php if (isset($_GET['success'])): ?>
    <div class="container">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_GET['success']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    </div>
  <?php endif; ?>

  <div class="container my-5">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <!-- Statistik Ulasan -->
        <div class="card">
          <div class="card-body text-center">
            <h3 class="card-title" style="color: #5F8B4C;">Statistik Ulasan Playlandia</h3>
            <div class="d-flex align-items-center justify-content-center mb-3">
              <div class="rating-stars me-3">
                <?php
                $avg_rating = round($review_stats['average'] ?? 0);
                for ($i = 1; $i <= 5; $i++) {
                  echo $i <= $avg_rating ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
                }
                ?>
              </div>
              <span class="fs-5"><?= number_format($review_stats['average'] ?? 0, 1) ?> dari 5 (<?= $review_stats['count'] ?? 0 ?> ulasan)</span>
            </div>
          </div>
        </div>

        <!-- Ulasan Pengguna -->
        <div class="card mt-4">
          <div class="card-body">
            <h3 class="card-title text-center" style="color: #5F8B4C;">Ulasan Anda</h3>
            
            <?php if (empty($user_reviews)): ?>
              <p class="text-center text-muted">Anda belum memberikan ulasan.</p>
            <?php else: ?>
              <?php foreach ($user_reviews as $review): ?>
                <div class="review-card">
                  <div class="review-header">
                    <div class="rating-stars">
                      <?php
                      for ($i = 1; $i <= 5; $i++) {
                        echo $i <= $review['rating'] ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
                      }
                      ?>
                    </div>
                    <div class="review-date">
                      <?= date('d M Y', strtotime($review['created_at'])) ?>
                    </div>
                  </div>
                  <?php if (!empty($review['comment'])): ?>
                    <p class="mt-2"><?= htmlspecialchars($review['comment']) ?></p>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>

            <hr class="my-4">
            
            <!-- Form Ulasan -->
            <h4 class="text-center mt-4" style="color: #5F8B4C;">Tambah Ulasan Baru</h4>
            <form method="POST" class="mt-4">
              <div class="mb-4 text-center">
                <label class="form-label d-block" style="color: #5F8B4C; font-weight: bold;">Rating</label>
                <div class="d-flex justify-content-center">
                  <?php for ($i = 1; $i <= 5; $i++): ?>
                    <div class="rating-option mx-1">
                      <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" <?= $i == 5 ? 'checked' : '' ?>>
                      <label for="star<?= $i ?>">
                        <i class="<?= $i <= 5 ? 'fas' : 'far' ?> fa-star"></i>
                      </label>
                    </div>
                  <?php endfor; ?>
                </div>
              </div>
              
              <div class="mb-4">
                <label for="comment" class="form-label" style="color: #5F8B4C; font-weight: bold;">Komentar (opsional)</label>
                <textarea class="form-control" id="comment" name="comment" rows="4" placeholder="Bagikan pengalaman Anda..."></textarea>
              </div>
              
              <div class="text-center">
                <button type="submit" class="btn btn-play px-4 py-2">
                  <i class="fas fa-paper-plane me-2"></i> Kirim Ulasan
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>