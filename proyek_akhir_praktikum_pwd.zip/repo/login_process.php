<?php
require_once __DIR__ . '/includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validasi input
        if (empty($_POST['username']) || empty($_POST['password'])) {
            throw new Exception("Username dan password harus diisi");
        }

        // Gunakan prepared statement
        $stmt = $conn->prepare("SELECT id, username, password, saldo FROM user WHERE username = ?");
        if (!$stmt) {
            throw new Exception("Prepare statement error: " . $conn->error);
        }

        $stmt->bind_param("s", $_POST['username']);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // Verifikasi password (untuk development)
            if ($_POST['password'] === $user['password']) {
                $_SESSION['user'] = [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'saldo' => $user['saldo']
                ];
                header("Location: home.php");
                exit();
            }
        }

        throw new Exception("Username atau password salah");

    } catch (Exception $e) {
        error_log("Login error: " . $e->getMessage());
        header("Location: login.php?error=" . urlencode($e->getMessage()));
        exit();
    }
}

header("Location: login.php");
exit();
?>