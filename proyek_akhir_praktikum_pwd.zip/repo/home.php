<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/game_stats.php';
validateSession();

// Data game
$games = [
  1 => [
    'name' => 'Clumsy Bird',
    'price' => 10000,
    'path' => 'play_game.php?game_id=1',
    'image' => 'assets/clumsybird.webp'
  ],
  2 => [
    'name' => 'Cars',
    'price' => 25000,
    'path' => 'play_game.php?game_id=2',
    'image' => 'assets/cars.jpg'
  ],
  3 => [
    'name' => 'Duck Hunt',
    'price' => 12000,
    'path' => 'play_game.php?game_id=3',
    'image' => 'assets/duckhunt.png'
  ],
  4 => [
    'name' => 'Hextris',
    'price' => 9000,
    'path' => 'play_game.php?game_id=4',
    'image' => 'assets/hextris.webp'
  ],
  5 => [
    'name' => 'Snake',
    'price' => 8000,
    'path' => 'play_game.php?game_id=5',
    'image' => 'assets/snake.png'
  ],
  6 => [
    'name' => 'Tetris',
    'price' => 5000,
    'path' => 'play_game.php?game_id=6',
    'image' => 'assets/tetris.png'
  ],
  7 => [
    'name' => '2048',
    'price' => 7000,
    'path' => 'play_game.php?game_id=7',
    'image' => 'assets/2048games.jpeg'
  ]
];

// Ambil top 3 game
$topGames = getTopGames(3);
// Ambil riwayat transaksi
$transactions = getUserTransactions($_SESSION['user']['id'], 5);
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Playlandia - Game Center</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    @font-face {
      font-family: 'Nexa';
      src: url('soopafre.ttf');
    }

    body {
      background-image: url('background.png');
      font-family: Arial, sans-serif;
      color: rgb(82, 44, 1);
      background-color: #5F8B4C;
      background-size: cover;
      background-attachment: fixed;
      min-height: 100vh;
    }

    .navbar {
      background-color: #5F8B4C;
      border-bottom: 5px solid rgb(255, 191, 0);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .navbar img {
      width: 50px;
      height: auto;
      transition: transform 0.3s ease;
    }

    .navbar img:hover {
      transform: scale(1.1);
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
      font-family: 'Nexa', sans-serif;
      color: #FFFBDE;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }

    .welcome-section {
      background: linear-gradient(135deg, rgba(95, 139, 76, 0.9) 0%, rgba(255, 215, 0, 0.8) 100%);
      padding: 2rem 0;
      margin-bottom: 2rem;
      border-radius: 0 0 20px 20px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
    }

    .welcome-title {
      font-size: 2.5rem;
      margin-bottom: 1rem;
    }

    .custom-btn {
      background-color: rgb(226, 49, 49);
      border-color: rgb(255, 191, 0);
      color: white;
      font-family: 'Nexa', sans-serif;
      font-size: 1rem;
      padding: 0.5rem 1.5rem;
      border-radius: 50px;
      transition: all 0.3s ease;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .custom-btn:hover {
      background-color: #FFD700;
      border-color: #5F8B4C;
      color: #5F8B4C;
      box-shadow: 0 6px 12px rgba(95, 139, 76, 0.3);
      transform: translateY(-2px);
    }

    .btn-play {
      background-color: #FFD700;
      color: #5F8B4C;
      font-family: 'Nexa', sans-serif;
      padding: 0.5rem 1.5rem;
      border-radius: 50px;
      text-decoration: none;
      display: inline-block;
      transition: all 0.3s ease;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      border: none;
    }

    .btn-play:hover {
      background-color: #5F8B4C;
      color: #FFFBDE;
      transform: translateY(-2px);
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    }

    .game-card {
      background: #FFFBDE;
      border-radius: 15px;
      padding: 20px;
      margin-bottom: 20px;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
      border: none;
    }

    .game-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.15);
    }

    .top-game-card {
      border-left: 5px solid #FFD700;
    }

    .game-thumbnail {
      width: 100%;
      height: 150px;
      object-fit: cover;
      border-radius: 10px;
      margin-bottom: 15px;
    }

    .play-count {
      font-size: 0.9em;
      color: #5F8B4C;
    }

    .card {
      background: #FFFBDE;
      border-radius: 15px;
      border: none;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
    }

    .card-title {
      color: #5F8B4C;
      font-family: 'Nexa', sans-serif;
    }

    .transaction-item {
      border-left: 4px solid #5F8B4C;
      padding: 10px;
      margin-bottom: 10px;
      background: #FFFBDE;
      border-radius: 8px;
      transition: transform 0.3s ease;
    }

    .transaction-item:hover {
      transform: translateY(-3px);
    }

    .topup-item {
      border-left-color: #FFD700;
    }

    .transaction-amount {
      font-weight: bold;
      font-family: 'Nexa', sans-serif;
    }

    .topup-amount {
      color: #5F8B4C;
    }

    .payment-amount {
      color: #E23137;
    }

    .balance {
      font-family: 'Nexa', sans-serif;
      font-size: 1.2rem;
      color: #FFFBDE;
      background-color: rgba(95, 139, 76, 0.7);
      padding: 0.5rem 1rem;
      border-radius: 50px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .section-title {
      font-family: 'Nexa', sans-serif;
      color: #FFFBDE;
      text-align: center;
      margin: 2rem 0;
      font-size: 2rem;
      position: relative;
    }

    .section-title:after {
      content: "";
      display: block;
      width: 100px;
      height: 4px;
      background: linear-gradient(to right, #5F8B4C, #FFD700);
      margin: 0.5rem auto 0;
      border-radius: 2px;
    }

    .modal-content {
      background-color: #FFFBDE;
      border-radius: 15px;
    }

    .modal-header {
      border-bottom: 2px solid #5F8B4C;
    }

    .modal-title {
      color: #5F8B4C;
      font-family: 'Nexa', sans-serif;
    }

    .form-control:focus {
      border-color: #5F8B4C;
      box-shadow: 0 0 0 0.25rem rgba(95, 139, 76, 0.25);
    }

    /* Offcanvas Styles */
    .offcanvas {
      background-color: #5F8B4C;
      color: #FFFBDE;
    }

    .offcanvas-header {
      border-bottom: 2px solid #FFD700;
    }

    .offcanvas-title {
      font-family: 'Nexa', sans-serif;
      color: #FFFBDE;
    }

    .offcanvas-body {
      padding: 0;
    }

    .user-profile {
      padding: 20px;
      background-color: rgba(95, 139, 76, 0.9);
      border-bottom: 1px solid rgba(255, 215, 0, 0.3);
    }

    .user-profile h5 {
      margin-bottom: 10px;
      color: #FFFBDE;
    }

    .user-profile p {
      margin-bottom: 5px;
      color: #FFFBDE;
    }

    .offcanvas-nav {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .offcanvas-nav li {
      border-bottom: 1px solid rgba(255, 215, 0, 0.3);
    }

    .offcanvas-nav a {
      display: block;
      padding: 15px 20px;
      color: #FFFBDE;
      text-decoration: none;
      transition: all 0.3s ease;
      font-size: 1.1rem;
    }

    .offcanvas-nav a:hover {
      background-color: rgba(255, 215, 0, 0.2);
      padding-left: 25px;
    }

    .offcanvas-nav i {
      width: 30px;
      text-align: center;
      margin-right: 10px;
    }

    .offcanvas-footer {
      padding: 20px;
      border-top: 1px solid rgba(255, 215, 0, 0.3);
    }

    @media (max-width: 768px) {
      .welcome-title {
        font-size: 2rem;
      }
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg sticky-top">
    <div class="container-fluid">
      <div class="d-flex align-items-center">
        <img src="logo.png" alt="Logo Playlandia">
        <h1 class="ms-2">PLAYLANDIA</h1>
      </div>

      <div class="ms-auto d-flex align-items-center gap-3">
        <span class="balance">Balance: Rp <?= number_format($_SESSION['user']['saldo'], 0, ',', '.') ?></span>
        <button class="btn custom-btn" data-bs-toggle="modal" data-bs-target="#topupModal">
          <i class="fas fa-coins"></i> Top Up
        </button>
        <button class="btn custom-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu"
          aria-controls="offcanvasMenu">
          <i class="fas fa-bars"></i>
        </button>
      </div>
    </div>
  </nav>

  <!-- Offcanvas Menu -->
  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasMenu" aria-labelledby="offcanvasMenuLabel">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="offcanvasMenuLabel">Profile User</h5>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <div class="user-profile">
        <h5><?= htmlspecialchars($_SESSION['user']['username']) ?></h5>
        <p><i class="fas fa-wallet me-2"></i> Balance: Rp <?= number_format($_SESSION['user']['saldo'], 0, ',', '.') ?>
        </p>
        <?php if (isset($_SESSION['user']['email'])): ?>
          <p><i class="fas fa-envelope me-2"></i> <?= htmlspecialchars($_SESSION['user']['email']) ?></p>
        <?php endif; ?>
      </div>

      <ul class="offcanvas-nav">
        <li>
          <a href="#" data-bs-toggle="modal" data-bs-target="#transactionModal">
            <i class="fas fa-history"></i> Transaction History
          </a>
        </li>
        <li>
          <a href="reviews.php">
            <i class="fas fa-star"></i> Ulasan Saya
          </a>
        </li>
        <li>
          <a href="logout.php">
            <i class="fas fa-sign-out-alt"></i> Logout
          </a>
        </li>
      </ul>
    </div>
    <div class="offcanvas-footer text-center">
      <small>&copy; 2025 Playlandia. All rights reserved.</small>
    </div>
  </div>

  <!-- Welcome Section -->
  <section class="welcome-section">
    <div class="container text-center">
      <h1 class="welcome-title">WELCOME BACK, <?= htmlspecialchars($_SESSION['user']['username']) ?>!</h1>
      <p class="welcome-subtitle" style="color: #FFFBDE;">Ready for some fun? Explore our game collection and start
        playing!</p>
    </div>
  </section>

  <?php if (isset($_GET['error'])): ?>
    <div class="container">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_GET['error']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    </div>
  <?php endif; ?>

  <?php if (isset($_GET['success'])): ?>
    <div class="container">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php
        $successMessages = [
          'topup_success' => 'Top up berhasil! Saldo Anda telah bertambah'
        ];
        echo $successMessages[$_GET['success']] ?? 'Operasi berhasil';
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    </div>
  <?php endif; ?>

  <!-- Top Up Modal -->
  <div class="modal fade" id="topupModal" tabindex="-1" aria-labelledby="topupModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="topupModalLabel">Top Up Balance</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form method="POST" action="topup_process.php">
          <div class="modal-body">
            <div class="mb-3">
              <label for="amount" class="form-label">Amount</label>
              <div class="input-group">
                <span class="input-group-text">Rp</span>
                <input type="number" class="form-control" id="amount" name="amount" min="10000" value="10000"
                  step="5000" required>
              </div>
              <small class="text-muted">Minimum Rp 10,000</small>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn custom-btn">Top Up Now</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Transaction History Modal -->
  <div class="modal fade" id="transactionModal" tabindex="-1" aria-labelledby="transactionModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="transactionModalLabel">Transaction History</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="user-info mb-4">
            <h5><?= htmlspecialchars($_SESSION['user']['username']) ?></h5>
            <p><i class="fas fa-wallet"></i> Balance: Rp <?= number_format($_SESSION['user']['saldo'], 0, ',', '.') ?>
            </p>
            <?php if (isset($_SESSION['user']['email'])): ?>
              <p><i class="fas fa-envelope"></i> <?= htmlspecialchars($_SESSION['user']['email']) ?></p>
            <?php endif; ?>
          </div>

          <h6><i class="fas fa-history"></i> Recent Transaction History</h6>
          <div class="dropdown-transactions">
            <?php if (!empty($transactions)): ?>
              <?php foreach ($transactions as $transaction): ?>
                <div class="transaction-item <?= $transaction['type'] === 'topup' ? 'topup-item' : '' ?>"
                  style="margin-bottom: 8px;">
                  <div class="d-flex justify-content-between">
                    <span style="font-size: 0.9rem;">
                      <?= $transaction['type'] === 'topup' ? 'Top Up' : 'Pembelian Game' ?>
                    </span>
                    <span
                      class="transaction-amount <?= $transaction['type'] === 'topup' ? 'topup-amount' : 'payment-amount' ?>"
                      style="font-size: 0.9rem;">
                      <?= $transaction['type'] === 'topup' ? '+' : '-' ?>
                      Rp <?= number_format($transaction['amount'], 0, ',', '.') ?>
                    </span>
                  </div>
                  <small class="text-muted" style="font-size: 0.8rem;">
                    <?= date('d M Y H:i', strtotime($transaction['created_at'])) ?>
                  </small>
                </div>
              <?php endforeach; ?>
            <?php else: ?>
              <p class="text-muted">No transactions found</p>
            <?php endif; ?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="row">
      <!-- Konten Utama -->
      <div class="col-lg-12">
        <!-- Bagian Top 3 Game -->
        <?php if (!empty($topGames)): ?>
          <div class="mb-5">
            <h2 class="section-title"><i class="fas fa-fire"></i> Top 3 Popular Games</h2>
            <div class="row">
              <?php foreach ($topGames as $game):
                $gameId = $game['game_id'];
                $gameData = $games[$gameId] ?? null;
                if ($gameData):
                  ?>
                  <div class="col-md-4 mb-4">
                    <div class="game-card top-game-card">
                      <?php if (!empty($gameData['image'])): ?>
                        <img src="<?= $gameData['image'] ?>" alt="<?= $gameData['name'] ?>" class="game-thumbnail">
                      <?php endif; ?>
                      <h3 style="color: #5F8B4C;"><?= htmlspecialchars($gameData['name']) ?></h3>
                      <p class="play-count"><i class="fas fa-gamepad"></i> Played <?= $game['play_count'] ?> times</p>
                      <p>Price: Rp <?= number_format($gameData['price'], 0, ',', '.') ?></p>
                      <a href="<?= $gameData['path'] ?>" class="btn-play"
                        onclick="return confirm('Play <?= $gameData['name'] ?>? You will be charged Rp <?= number_format($gameData['price'], 0, ',', '.') ?>')">
                        <i class="fas fa-play"></i> Play Now
                      </a>
                    </div>
                  </div>
                <?php endif; endforeach; ?>
            </div>
          </div>
        <?php endif; ?>


        <!-- Daftar Semua Game -->
        <h2 class="section-title"><i class="fas fa-gamepad"></i> All Games</h2>
        <div class="row">
          <?php foreach ($games as $id => $game): ?>
            <div class="col-md-6 mb-4">
              <div class="game-card">
                <?php if (!empty($game['image'])): ?>
                  <img src="<?= $game['image'] ?>" alt="<?= $game['name'] ?>" class="game-thumbnail">
                <?php endif; ?>
                <h3 style="color: #5F8B4C;"><?= htmlspecialchars($game['name']) ?></h3>
                <p>Price: Rp <?= number_format($game['price'], 0, ',', '.') ?></p>
                <a href="<?= $game['path'] ?>" class="btn-play"
                  onclick="return confirm('Play <?= $game['name'] ?>? You will be charged Rp <?= number_format($game['price'], 0, ',', '.') ?>')">
                  <i class="fas fa-play"></i> Play Now
                </a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- About Section -->
  <section class="about-section mb-5">
    <div class="container">
      <div class="card p-4">
        <h2 class="section-title"><i class="fas fa-info-circle"></i> About Playlandia</h2>
        <div class="row">
          <div class="col-md-6">
            <p>Playlandia is an online gaming platform that offers a wide variety of fun and entertaining games for all
              ages. With a simple and secure payment system, you can enjoy high-quality games with just one click.</p>
            <p>We are committed to providing a fun and seamless gaming experience. Every game on Playlandia has
              undergone a rigorous selection process to ensure its quality and safety.</p>
          </div>
          <div class="col-md-6">
            <div class="card bg-light p-3">
              <h5><i class="fas fa-star text-warning"></i> Advantages of Playlandia:</h5>
              <ul>
                <li>High-quality game collection</li>
                <li>Secure payment system</li>
                <li>User-friendly interface</li>
                <li>24/7 customer support</li>
                <li>Regular game updates</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>