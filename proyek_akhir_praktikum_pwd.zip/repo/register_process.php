<?php
require_once __DIR__ . '/includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validasi input
        $username = trim($_POST['username']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        $saldo = (int) $_POST['saldo'];

        if (empty($username) || empty($password)) {
            throw new Exception("Username dan password harus diisi");
        }

        if (strlen($password) < 6) {
            throw new Exception("Password minimal 6 karakter");
        }

        if ($password !== $confirm_password) {
            throw new Exception("Konfirmasi password tidak sesuai");
        }

        if ($saldo < 5000) {
            throw new Exception("Minimal top up saldo Rp 5.000");
        }

        // Cek username sudah ada
        $stmt = $conn->prepare("SELECT id FROM user WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            throw new Exception("Username sudah digunakan");
        }

        // Enkripsi password (untuk production, gunakan password_hash())
        $hashed_password = $password;

        // Insert user baru
        $stmt = $conn->prepare("INSERT INTO user (username, password, saldo) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $username, $hashed_password, $saldo);

        if (!$stmt->execute()) {
            throw new Exception("Gagal membuat akun: " . $conn->error);
        }

        // Auto login setelah registrasi
        $user_id = $conn->insert_id;
        $_SESSION['user'] = [
            'id' => $user_id,
            'username' => $username,
            'saldo' => $saldo
        ];

        header("Location: home.php");
        exit();

    } catch (Exception $e) {
        header("Location: register.php?error=" . urlencode($e->getMessage()));
        exit();
    }
}

header("Location: register.php");
exit();