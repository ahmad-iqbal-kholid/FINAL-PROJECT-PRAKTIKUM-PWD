<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';

validateSession();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $amount = (int) $_POST['amount'];

        if ($amount < 10000) {
            throw new Exception("Minimal top up Rp 10.000");
        }

        if ($amount > 1000000) {
            throw new Exception("Maksimal top up Rp 1.000.000");
        }

        // Proses top up
        addBalance($amount);

        header("Location: home.php?success=topup_success&amount=" . $amount);
        exit();

    } catch (Exception $e) {
        header("Location: home.php?error=" . urlencode($e->getMessage()));
        exit();
    }
}

header("Location: home.php");
exit();
?>