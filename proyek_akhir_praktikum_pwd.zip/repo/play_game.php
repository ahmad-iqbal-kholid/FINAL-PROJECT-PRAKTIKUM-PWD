<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/game_stats.php';

validateSession();

$game_id = (int) $_GET['game_id'];

$games = [
    1 => [
        'name' => 'Clumsy Bird',
        'price' => 10000,
        'path' => 'clumsybird' // Hanya nama folder
    ],
    2 => [
        'name' => 'Cars',
        'price' => 25000,
        'path' => 'cars'
    ],
    3 => [
        'name' => 'Duck Hunt',
        'price' => 12000,
        'path' => 'duckhunt/dist'
    ],
    4 => [
        'name' => 'Hextris',
        'price' => 9000,
        'path' => 'hextris'
    ],
    5 => [
        'name' => 'Snake',
        'price' => 8000,
        'path' => 'snake'
    ],
    6 => [
        'name' => 'Tetris',
        'price' => 5000,
        'path' => 'tetris'
    ],
    7 => [
        'name' => '2048',
        'price' => 7000,
        'path' => '2048master'
    ],
];

// Validasi game ID
if (!isset($games[$game_id])) {
    header("Location: home.php?error=invalid_game");
    exit();
}

// Cek saldo
if ($_SESSION['user']['saldo'] < $games[$game_id]['price']) {
    header("Location: home.php?error=insufficient_balance");
    exit();
}

// PROSES UTAMA
try {
    $conn->begin_transaction();

    // 1. Kurangi saldo
    $update = $conn->query("UPDATE user SET saldo = saldo - {$games[$game_id]['price']} WHERE id = {$_SESSION['user']['id']}");

    if (!$update) {
        throw new Exception("Gagal mengurangi saldo");
    }

    // 2. Catat statistik permainan
    recordGamePlay($game_id, $_SESSION['user']['id']);

    // 3. Commit transaksi
    $conn->commit();

    // 4. Update session
    $_SESSION['user']['saldo'] -= $games[$game_id]['price'];

    // 5. Redirect ke game
    $game_folder = $games[$game_id]['path'];
    header("Location: ../repo/games/$game_folder/index.html");
    exit();

} catch (Exception $e) {
    $conn->rollback();
    header("Location: home.php?error=db_error");
    exit();
}
?>