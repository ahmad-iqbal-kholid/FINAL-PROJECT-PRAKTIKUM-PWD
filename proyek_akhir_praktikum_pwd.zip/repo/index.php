<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Playlandia - Fun Games for Everyone</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    body {
      background-image: url('background.png');
      font-family: Arial, sans-serif;
      color: rgb(82, 44, 1);
      background-color: #5F8B4C;
      background-size: cover;
      background-attachment: fixed;
      min-height: 100vh;
    }

    .navbar {
      background-color: #5F8B4C;
      border-bottom: 5px solid rgb(255, 191, 0);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    @font-face {
      font-family: 'Nexa';
      src: url('soopafre.ttf');
    }

    h1 {
      font-family: 'Nexa', sans-serif;
      color: #FFFBDE;
      font-size: 2.5rem;
      margin: 0;
      padding: 5px;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }

    .welcome-section {
      background: linear-gradient(135deg, rgba(95, 139, 76, 0.9) 0%, rgba(255, 215, 0, 0.8) 100%);
      padding: 3rem 0;
      margin-bottom: 2rem;
      border-radius: 0 0 20px 20px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
    }

    .welcome-title {
      font-family: 'Nexa', sans-serif;
      color: #FFFBDE;
      font-size: 3.5rem;
      text-align: center;
      margin-bottom: 1rem;
      text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.3);
    }

    .welcome-subtitle {
      color: #FFFBDE;
      text-align: center;
      font-size: 1.5rem;
      max-width: 800px;
      margin: 0 auto;
      opacity: 0.9;
    }

    img {
      width: 50px;
      height: auto;
      transition: transform 0.3s ease;
    }

    img:hover {
      transform: scale(1.1);
    }

    .custom-btn {
      background-color: rgb(226, 49, 49);
      border-color: rgb(255, 191, 0);
      color: white;
      font-family: 'Nexa', sans-serif;
      font-size: 1rem;
      padding: 0.5rem 1.5rem;
      border-radius: 50px;
      transition: all 0.3s ease;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .custom-btn:hover {
      background-color: #FFD700;
      border-color: #5F8B4C;
      color: #5F8B4C;
      box-shadow: 0 6px 12px rgba(95, 139, 76, 0.3);
      transform: translateY(-2px);
    }

    .scrollable-card-group {
      display: flex;
      overflow-x: auto;
      padding: 1rem 0;
      scroll-behavior: smooth;
    }

    .scrollable-card-group::-webkit-scrollbar {
      height: 8px;
    }

    .scrollable-card-group::-webkit-scrollbar-thumb {
      background-color: #5F8B4C;
      border-radius: 10px;
    }

    .scrollable-card-group .card {
      flex: 0 0 auto;
      width: 300px;
      margin-right: 15px;
      border-radius: 15px;
      overflow: hidden;
      border: none;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .scrollable-card-group .card:hover {
      transform: translateY(-10px);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.15);
    }

    .card-img-top {
      height: 200px;
      object-fit: cover;
    }

    .card-body {
      background-color: #FFFBDE;
    }

    .card-title {
      font-family: 'Nexa', sans-serif;
      color: #5F8B4C;
      font-weight: bold;
    }

    .section-title {
      font-family: 'Nexa', sans-serif;
      color: #5F8B4C;
      text-align: center;
      margin: 2rem 0;
      font-size: 2.5rem;
      position: relative;
    }

    .section-title:after {
      content: "";
      display: block;
      width: 100px;
      height: 4px;
      background: linear-gradient(to right, #5F8B4C, #FFD700);
      margin: 0.5rem auto 0;
      border-radius: 2px;
    }

    /* Testimonials Section */
    .testimonials-section {
      padding: 3rem 0;
      background: linear-gradient(135deg, rgba(255, 215, 0, 0.1) 0%, rgba(95, 139, 76, 0.1) 100%);
    }

    .testimonial-card {
      background-color: white;
      border-radius: 15px;
      padding: 2rem;
      margin: 1rem;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
      transition: transform 0.3s ease;
    }

    .testimonial-card:hover {
      transform: translateY(-5px);
    }

    .player-avatar {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid #FFD700;
      margin-bottom: 1rem;
    }

    .player-name {
      font-family: 'Nexa', sans-serif;
      color: #5F8B4C;
      font-weight: bold;
      margin-bottom: 0.5rem;
    }

    .player-rating {
      color: #FFD700;
      margin-bottom: 1rem;
    }

    /* Call-to-Action Section */
    .cta-section {
      background: linear-gradient(135deg, #5F8B4C 0%, #FFD700 100%);
      padding: 4rem 0;
      text-align: center;
      color: white;
      margin: 3rem 0;
      border-radius: 20px;
    }

    .cta-title {
      font-family: 'Nexa', sans-serif;
      font-size: 2.5rem;
      margin-bottom: 1.5rem;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }

    .cta-btn {
      background-color: white;
      color: #5F8B4C;
      font-family: 'Nexa', sans-serif;
      font-size: 1.2rem;
      padding: 0.8rem 2.5rem;
      border-radius: 50px;
      border: none;
      transition: all 0.3s ease;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    }

    .cta-btn:hover {
      background-color: #FFFBDE;
      transform: translateY(-3px);
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
    }

    /* Footer */
    footer {
      background-color: #5F8B4C;
      padding: 3rem 0;
      text-align: center;
      margin-top: 3rem;
      border-top: 5px solid rgb(255, 191, 0);
    }

    .footer-links {
      display: flex;
      justify-content: center;
      gap: 2rem;
      margin-bottom: 1.5rem;
      flex-wrap: wrap;
    }

    .footer-links a {
      color: #ffffff;
      text-decoration: none;
      opacity: 0.7;
      transition: opacity 0.3s ease, transform 0.3s ease;
      font-size: 1.1rem;
    }

    .footer-links a:hover {
      opacity: 1;
      transform: translateY(-2px);
    }

    .social-icons {
      margin: 1.5rem 0;
    }

    .social-icons a {
      color: white;
      font-size: 1.5rem;
      margin: 0 10px;
      opacity: 0.7;
      transition: opacity 0.3s ease, transform 0.3s ease;
    }

    .social-icons a:hover {
      opacity: 1;
      transform: translateY(-3px);
    }

    .copyright {
      opacity: 0.6;
      font-size: 0.9rem;
      color: white;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
      .welcome-title {
        font-size: 2.5rem;
      }

      .welcome-subtitle {
        font-size: 1.2rem;
        padding: 0 1rem;
      }

      .scrollable-card-group .card {
        width: 250px;
      }

      .cta-title {
        font-size: 2rem;
      }
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg sticky-top">
    <div class="container-fluid">
      <img src="logo.png" alt="Logo Playlandia">
      <h1>PLAYLANDIA</h1>
      <div class="ms-auto">
        <a href="register.php" class="btn btn-sm custom-btn me-2">REGISTER</a>
        <a href="login.php" class="btn btn-sm custom-btn">LOGIN</a>
      </div>
    </div>
  </nav>

  <!-- Welcome Section -->
  <section class="welcome-section">
    <div class="container">
      <h1 class="welcome-title">WELCOME TO PLAYLANDIA!</h1>
      <p class="welcome-subtitle">Discover endless fun with our collection of exciting games for all ages. Join our
        community and start playing today!</p>
    </div>
  </section>

  <!-- Popular Games Section -->
  <div class="container">
    <h2 class="section-title">Popular Games</h2>
    <div class="scrollable-card-group">
      <div class="card">
        <img src="assets/clumsybird.webp" class="card-img-top" alt="Game 1">
        <div class="card-body">
          <h5 class="card-title">Clumsy Bird</h5>
          <p class="card-text">Clumsy Bird is a fun Flappy Bird clone that has pretty much the same gameplay as its
            inspiration.</p>
        </div>
      </div>
      <div class="card">
        <img src="assets/duckhunt.png" class="card-img-top" alt="Game 2">
        <div class="card-body">
          <h5 class="card-title">Duck Hunt</h5>
          <p class="card-text">Duck Hunt is a fantastic arcade game that takes inspiration from the original classic.
          </p>
        </div>
      </div>
      <div class="card">
        <img src="assets/hextris.webp" class="card-img-top" alt="Game 3">
        <div class="card-body">
          <h5 class="card-title">Hextris</h5>
          <p class="card-text">Hextris is a challenging and intriguing puzzle game in which you must try and stack a
            series of different colored blocks in a hexagonal formation.</p>
        </div>
      </div>
      <div class="card">
        <img src="assets/cars.jpg" class="card-img-top" alt="Game 4">
        <div class="card-body">
          <h5 class="card-title">Cars</h5>
          <p class="card-text">Retro Car Driver is a classic car driving game. </p>
        </div>
      </div>
      <div class="card">
        <img src="assets/2048games.jpeg" class="card-img-top" alt="Game 5">
        <div class="card-body">
          <h5 class="card-title">2048 Games</h5>
          <p class="card-text">Join the numbers and get to the 2048 tile!</p>
        </div>
      </div>
      <div class="card">
        <img src="assets/snake.png" class="card-img-top" alt="Game 6">
        <div class="card-body">
          <h5 class="card-title">Snake Games</h5>
          <p class="card-text">Play the classic retro mobile phone game in your web browser! Guide the snake towards the
            food but avoid your ever-growing tail.</p>
        </div>
      </div>
    </div>
  </div>

  <!-- Reviews Section -->
  <section class="container my-5">
    <div class="card">
      <div class="card-body">
        <h2 class="section-title">User Reviews</h2>

        <?php
        // Initialize variables
        $recent_reviews = [];
        $conn = null;

        // Try to connect to database if not already connected
        try {
          // Replace these with your actual database credentials
          $conn = new mysqli("localhost", "username", "password", "database_name");

          if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
          }

          // Ambil beberapa ulasan terbaru
          $result = $conn->query("
                    SELECT r.*, u.username 
                    FROM reviews r
                    JOIN user u ON r.user_id = u.id
                    ORDER BY r.created_at DESC 
                    LIMIT 3
                ");

          if ($result) {
            $recent_reviews = $result->fetch_all(MYSQLI_ASSOC);
          }
        } catch (Exception $e) {
          // Handle database errors silently for production
          // For debugging, you could uncomment:
          // echo "Database error: " . $e->getMessage();
        }
        ?>

        <?php if (!empty($recent_reviews)): ?>
          <div class="row">
            <?php foreach ($recent_reviews as $review): ?>
              <div class="col-md-4 mb-4">
                <div class="review-card">
                  <div class="review-header">
                    <span class="review-user"><?= htmlspecialchars($review['username']) ?></span>
                    <span class="review-date">
                      <?= date('d M Y', strtotime($review['created_at'])) ?>
                    </span>
                  </div>
                  <div class="rating-stars mb-2">
                    <?php
                    for ($i = 1; $i <= 5; $i++) {
                      echo $i <= $review['rating'] ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
                    }
                    ?>
                  </div>
                  <?php if (!empty($review['comment'])): ?>
                    <p class="mb-0"><?= htmlspecialchars($review['comment']) ?></p>
                  <?php endif; ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <p class="text-center text-muted">No reviews yet. Be the first to leave a review!</p>
        <?php endif; ?>

        <div class="text-center mt-4">
          <a href="login.php" class="btn btn-primary">View All Reviews</a>
          <?php if (isset($_SESSION['user'])): ?>
            <a href="login.php" class="btn btn-outline-primary ms-2">Leave a Review</a>
          <?php else: ?>
            <a href="login.php" class="btn btn-outline-primary ms-2">Login to Leave a Review</a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </section>

  <!-- Call-to-Action Section -->
  <section class="container">
    <div class="cta-section">
      <h2 class="cta-title">Ready to Start Playing?</h2>
      <p class="welcome-subtitle">Join thousands of happy players and discover your next favorite game today!</p>
      <a href="register.php" class="btn cta-btn">JOIN NOW - IT'S FREE!</a>
    </div>
  </section>


  <!-- Footer -->
  <footer>
    <div class="container">
      <div class="footer-links">
        <a href="playlandia/about.html">About Us</a>
        <a href="playlandia/privacypolicy.html">Privacy Policy</a>
        <a href="playlandia/terms.html">Terms & Conditions</a>
        <a href="playlandia/help.html">Help</a>
        <a href="playlandia/contact.html">Contact</a>
      </div>
      <div class="social-icons">
        <a href="#"><i class="fab fa-facebook"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-youtube"></i></a>
        <a href="#"><i class="fab fa-discord"></i></a>
      </div>
      <p class="copyright">© 2025 Playlandia. All rights reserved.</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO"
    crossorigin="anonymous"></script>
</body>

</html>