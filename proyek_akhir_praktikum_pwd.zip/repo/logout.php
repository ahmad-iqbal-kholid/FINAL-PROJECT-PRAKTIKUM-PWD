<?php
require_once 'includes/config.php';

// Hapus semua data session
$_SESSION = [];
session_destroy();

// Redirect ke halaman login
header("Location: index.php");
exit();
?>