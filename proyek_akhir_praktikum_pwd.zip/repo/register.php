<?php
require_once __DIR__ . '/includes/auth.php';

// Jika user sudah login, redirect ke home
if (isLoggedIn()) {
    header("Location: home.php");
    exit();
}

$error = $_GET['error'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - PLAYLANDIA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-image: url('background.png');
            font-family: Arial, sans-serif;
            color: rgb(82, 44, 1);
            background-color: #FFDDAB;
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            margin: 0;
        }

        @font-face {
            font-family: 'Nexa';
            src: url('soopafre.ttf');
        }

        .register-wrapper {
            background-color: rgba(255, 251, 222, 0.9);
            border-radius: 20px;
            padding: 2.5rem;
            width: 100%;
            max-width: 500px;
            margin: 2rem auto;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
            border: 3px solid rgb(255, 191, 0);
        }

        .register-title {
            font-family: 'Nexa', sans-serif;
            color: #5F8B4C;
            text-align: center;
            margin-bottom: 1.5rem;
            font-size: 2.2rem;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
        }

        .form-control {
            border-radius: 50px;
            padding: 0.8rem 1.2rem;
            margin-bottom: 1rem;
            border: 2px solid #5F8B4C;
        }

        .form-control:focus {
            border-color: #FFD700;
            box-shadow: 0 0 0 0.25rem rgba(255, 215, 0, 0.25);
        }

        .btn-register {
            background-color: #5F8B4C;
            border: none;
            color: white;
            font-family: 'Nexa', sans-serif;
            font-size: 1.1rem;
            padding: 0.8rem;
            border-radius: 50px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
            margin-top: 1rem;
        }

        .btn-register:hover {
            background-color: #FFD700;
            color: #5F8B4C;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(95, 139, 76, 0.3);
        }

        .login-link {
            text-align: center;
            margin-top: 1.5rem;
            color: #5F8B4C;
        }

        .login-link a {
            color: #5F8B4C;
            font-weight: bold;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .login-link a:hover {
            color: #FFD700;
            text-decoration: underline;
        }

        .error {
            color: #e74c3c;
            background-color: #FFFBDE;
            padding: 0.8rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            text-align: center;
            border-left: 4px solid #e74c3c;
            font-weight: bold;
        }

        .logo {
            display: block;
            margin: 0 auto 1.5rem;
            width: 70px;
            height: auto;
        }

        label {
            font-weight: bold;
            color: #5F8B4C;
            margin-left: 0.5rem;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="register-wrapper">
            <img src="logo.png" alt="Playlandia Logo" class="logo">
            <h2 class="register-title">REGISTER</h2>

            <?php if ($error): ?>
                <div class="error">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="register_process.php">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required minlength="6">
                </div>

                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                </div>

                <div class="mb-3">
                    <label for="saldo" class="form-label">Initial Balance (Minimum Rp 5,000)</label>
                    <input type="number" class="form-control" id="saldo" name="saldo" min="5000" value="5000" required>
                    <small class="text-muted" style="margin-left: 0.5rem;">Balance will be available immediately after
                        registration</small>
                </div>

                <button type="submit" class="btn btn-register">REGISTER NOW</button>
            </form>

            <div class="login-link">
                Already have an account? <a href="login.php">Login here</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>