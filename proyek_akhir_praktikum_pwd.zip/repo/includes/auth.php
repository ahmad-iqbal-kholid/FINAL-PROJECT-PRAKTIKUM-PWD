<?php
// includes/auth.php
require_once __DIR__ . '/config.php';

function isLoggedIn() {
    return isset($_SESSION['user']);
}

function validateSession() {
    if (!isLoggedIn()) {
        header("Location: ../login.php");
        exit();
    }
}

function checkBalance($amount) {
    return ($_SESSION['user']['saldo'] ?? 0) >= $amount;
}

function deductBalance($amount) {
    global $conn;
    $user_id = $_SESSION['user']['id'];
    
    $stmt = $conn->prepare("UPDATE user SET saldo = saldo - ? WHERE id = ?");
    $stmt->bind_param("ii", $amount, $user_id);
    $stmt->execute();
    
    $_SESSION['user']['saldo'] -= $amount;
}

function addBalance($amount) {
    global $conn;
    $user_id = $_SESSION['user']['id'];
    
    // Update user balance
    $stmt = $conn->prepare("UPDATE user SET saldo = saldo + ? WHERE id = ?");
    $stmt->bind_param("ii", $amount, $user_id);
    $stmt->execute();
    
    // Record transaction
    $type = 'topup';
    $stmt = $conn->prepare("INSERT INTO transactions (user_id, amount, type, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iis", $user_id, $amount, $type);
    $stmt->execute();
    
    // Update session
    $_SESSION['user']['saldo'] += $amount;
}

function getUserTransactions($user_id, $limit = 10) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
    $stmt->bind_param("ii", $user_id, $limit);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}


?>

