<?php
// Fungsi untuk mencatat permainan
function recordGamePlay($game_id, $user_id) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO game_plays (game_id, user_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $game_id, $user_id);
    $stmt->execute();
}

// Fungsi untuk mendapatkan top 3 game
function getTopGames($limit = 3) {
    global $conn;
    $query = "
        SELECT game_id, COUNT(*) as play_count 
        FROM game_plays 
        GROUP BY game_id 
        ORDER BY play_count DESC 
        LIMIT ?
    ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}


?>