<?php
// Baris pertama pastikan include path benar
require_once __DIR__ . '/includes/auth.php';

// panggil isLoggedIn()
if (isLoggedIn()) {
  header("Location: home.php");
  exit();
}

$error = $_GET['error'] ?? null;
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Playlandia - Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    body {
      background-image: url('background.png');
      font-family: Arial, sans-serif;
      color: rgb(82, 44, 1);
      background-color: #FFDDAB;
      background-size: cover;
      background-attachment: fixed;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }

    @font-face {
      font-family: 'Nexa';
      src: url('soopafre.ttf');
    }

    .login-wrapper {
      background-color: rgba(255, 251, 222, 0.9);
      border-radius: 20px;
      padding: 2.5rem;
      width: 100%;
      max-width: 450px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
      border: 3px solid rgb(255, 191, 0);
    }

    .login-title {
      font-family: 'Nexa', sans-serif;
      color: #5F8B4C;
      text-align: center;
      margin-bottom: 1.5rem;
      font-size: 2.2rem;
      text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
    }

    .form-control {
      border-radius: 50px;
      padding: 0.8rem 1.2rem;
      margin-bottom: 1rem;
      border: 2px solid #5F8B4C;
    }

    .form-control:focus {
      border-color: #FFD700;
      box-shadow: 0 0 0 0.25rem rgba(255, 215, 0, 0.25);
    }

    .btn-login {
      background-color: #5F8B4C;
      border: none;
      color: white;
      font-family: 'Nexa', sans-serif;
      font-size: 1.1rem;
      padding: 0.8rem;
      border-radius: 50px;
      transition: all 0.3s ease;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      width: 100%;
      margin-top: 0.5rem;
    }

    .btn-login:hover {
      background-color: #FFD700;
      color: #5F8B4C;
      transform: translateY(-2px);
      box-shadow: 0 6px 12px rgba(95, 139, 76, 0.3);
    }

    .register-link {
      text-align: center;
      margin-top: 1.5rem;
      color: #5F8B4C;
    }

    .register-link a {
      color: #5F8B4C;
      font-weight: bold;
      text-decoration: none;
      transition: color 0.3s ease;
    }

    .register-link a:hover {
      color: #FFD700;
      text-decoration: underline;
    }

    .error {
      color: #e74c3c;
      background-color: #FFFBDE;
      padding: 0.8rem;
      border-radius: 10px;
      margin-bottom: 1.5rem;
      text-align: center;
      border-left: 4px solid #e74c3c;
      font-weight: bold;
    }

    .logo {
      display: block;
      margin: 0 auto 1.5rem;
      width: 70px;
      height: auto;
    }
  </style>
</head>

<body>
  <div class="login-wrapper">
    <img src="logo.png" alt="Playlandia Logo" class="logo">
    <h2 class="login-title">LOGIN</h2>

    <?php if ($error): ?>
      <div class="error">
        <?= ($error === '1') ? "Username/Password salah!" : "Silakan login!" ?>
      </div>
    <?php endif; ?>

    <form action="login_process.php" method="post">
      <input type="text" class="form-control" name="username" placeholder="Username" required>
      <input type="password" class="form-control" name="password" placeholder="Password" required>
      <button type="submit" class="btn-login">LOGIN</button>
    </form>

    <p class="register-link">Don't have account?<a href="register.php">Register here</a></p>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO"
    crossorigin="anonymous"></script>
</body>

</html>